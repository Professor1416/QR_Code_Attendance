<?php 
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
{
  header("location: login.php");
  exit;
}
else 
{
  include 'partials/_dbconnect.php';

} 
 ?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="favicon.jpg" rel="icon" type="image/jpg" />
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/welcome.css" rel="stylesheet">
    <title>Welcome <?php $_SESSION['username']; ?></title>
  </head>
  <body>
    
    <?php require 'partials/_nav.php'?>
    
    <div class="container my-3" >
      <div class="alert alert-success" role="alert">
        <h4 class="alert-heading">WelCome - <?php echo $_SESSION['username'] ?></h4>
      </div>
    <button type="submit" class="btn btn-primary" onclick="location.href='welcome.php';">Back</button>
    <button type="submit" class="btn btn-primary" onclick="location.href='addstudent.php';">Add Student</button>
    </div>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">Roll NO</th>
      <th scope="col">Name</th>
      <th scope="col">Gender</th>
      <th scope="col">CRN No</th>
      <th scope="col">Class</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
  <?php 
       $sql = "SELECT *  FROM `tystudent`"; 
        $result = mysqli_query($conn, $sql);
        if ($result) 
        {
          while($row = mysqli_fetch_assoc($result))
          {
            $srollNo = $row["srollno"];
            $sfirstName = $row["sfirstname"];
            $smiddleName = $row["smiddlename"];
            $slastName  = $row["slastname"];
            $sgender = $row["sgender"];
            $scrn = $row["scrn"];
            $sclass = $row["sclass"];

            echo '
            <tr>
              <th scope="row">'.$srollNo.'</th>
              <td>'.$slastName.' '.$sfirstName.' '.$smiddleName.'</td>
              <td>'.$sgender.'</td>
              <td>'.$scrn.'</td>
              <td>'.$sclass.'</td>
            </tr>';
          }  
        }
  ?>
  </tbody>
</table>
  </body>
</html>