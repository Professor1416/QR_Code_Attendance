<?php 
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
{
    header("location: login.php");
    exit;

}
else
{
        include 'partials/_dbconnect.php';
        $sql = "SELECT *  FROM `subjects`"; 
        $result = mysqli_query($conn, $sql);
        if ($result) 
        {
          while($row = mysqli_fetch_assoc($result))
          {
            $subjectID = $row["subject_id"];

           }
           
        }

        //echo $subjectID;
    require_once('phpqrcode/qrlib.php');
    function generateQRCode($data, $filename) 
    {
    $errorCorrectionLevel = 'H'; 
    $matrixPointSize = 10; 
    QRcode::png($data, $filename, $errorCorrectionLevel, $matrixPointSize);
}

$Date = date("Y-m-d");
$filename = 'qr_codes/'.$subjectID.'-'.$Date.'.png'; 


generateQRCode($subjectID, $filename);


echo '<body>';
echo '<div style="text-align: center;">';
echo '<img src="'.$filename.'" alt="QR Code">';
echo '<h3>Scan QR Code For Java - II</h3>';
echo '</div>';
echo '</body>';
}
 ?>