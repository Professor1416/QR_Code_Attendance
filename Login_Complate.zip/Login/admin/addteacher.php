<?php 
session_start();
$showAlert = false;
$showError = false;
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
{
  header("location: login.php");
  exit;
}
else if($_SERVER['REQUEST_METHOD'] == "POST")
{
  include 'partials/_dbconnect.php';
  $tId = $_POST["tId"];
  $tfirstName = $_POST["tfirstname"];
  $tmiddleName = $_POST["tmiddlename"];
  $tlastName  = $_POST["tlastname"];
  $tgender = $_POST["tgender"];
  //$sclass = $_POST["sclass"];

  //Check whether this scrn Exist
  $existSql = "SELECT *  FROM `teacher` WHERE tId ='$tId'"; 
  $result = mysqli_query($conn, $existSql); 
  $numExistRows = mysqli_num_rows($result);
  if($numExistRows > 0)
    {
    $showError = "Teacher Already Exists..!";
  }
  else
  {
    $sql = "INSERT INTO `teacher` (`tId`,`tfirstName`, `tmiddleName`,`tlastName`, `tgender`,`tdateCreated`) VALUES ('$tId','$tfirstName', '$tmiddleName','$tlastName','$tgender', current_timestamp())";
    $result = mysqli_query($conn, $sql);
    if($result)
      {
      $showAlert = true;
    }
  }
} 
 ?>
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="favicon.jpg" rel="icon" type="image/jpg" />
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/welcome.css" rel="stylesheet">
  </head>
  <body>  
    <?php require 'partials/_nav.php'?>
     <?php 
    if ($showAlert) {
      echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success..!</strong> Teacher Data Added... 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
     if ($showError) {
      echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error..!</strong>'.$showError.'
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
  ?>
    <h1>Add Teacher</h1>
    <form method="post">
      <label>Teacher Id:</label>
      <input type="number" name="tId">
      <div class="row">
        <div class="col">
          <label>Enter First Name:</label>
            <input type="text" name="tfirstname" class="form-control" placeholder="First name" required="">
        </div>
        <div class="col">
          <label>Enter Middle Name:</label>
            <input type="text" name="tmiddlename" class="form-control" placeholder="Middle name" required="">
        </div>
        <div class="col">
          <label>Enter Last Name:</label>
            <input type="text" name="tlastname"class="form-control" placeholder="Last name" required="">
        </div>
      </div><br>
      <div class="form-check">
      <label>Gender: </label>
      <input type="radio" name="tgender" value="Male">Male
    <input type="radio" name="tgender" value="Female">Female
    <input type="radio" name="tgender" value="Other">Other
  </div>  
    <br>
    <button type="submit" class="btn btn-primary">Submit</button>
      <button type="reset" class="btn btn-primary">Reset</button>
      </fieldset>
  </form>
</body>
</html>
