<?php 
$server = "localhost";
$username = "root";
$password = "";
$database = "qr_attendance";

$conn = mysqli_connect($server, $username, $password, $database);
if (!$conn) {
//	echo "success";
//}
//else{
	die("Error".mysql_connect_error()); 
}

 ?>