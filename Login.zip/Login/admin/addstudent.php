<?php 
session_start();
$showAlert = false;
$showError = false;
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
{
	header("location: login.php");
	exit;
}
else if($_SERVER['REQUEST_METHOD'] == "POST")
{
	include 'partials/_dbconnect.php';
	$srollNo = $_POST["srollno"];
	$sfirstName = $_POST["sfirstname"];
	$smiddleName = $_POST["smiddlename"];
	$slastName	= $_POST["slastname"];
	$sgender = $_POST["sgender"];
	$scrn = $_POST["scrn"];
	$sclass = $_POST["sclass"];
	
	//Check whether this scrn Exist
	$existSql = "SELECT *  FROM `tystudent` WHERE scrn ='$scrn'"; 
	$result = mysqli_query($conn, $existSql);
	$numExistRows = mysqli_num_rows($result);
	if($numExistRows > 0)
  	{
		$showError = "Student Already Exists..!";
	}
	else
	{
		$sql = "INSERT INTO `tystudent` (`srollNo`,`sfirstName`, `smiddleName`,`slastName`, `sgender`, `scrn`,`sclass`,`sdateCreated`) VALUES ('$srollNo','$sfirstName', '$smiddleName','$slastName','$sgender','$scrn','$sclass', current_timestamp())";
		$result = mysqli_query($conn, $sql);
		if($result)
   		{
			$showAlert = true;
		}
	}
}
 /*
 	CREATE TABLE `student` (
  `sId` int(10) NOT NULL,
  `sfirstName` varchar(255) NOT NULL,
  `smiddleName` varchar(255) NOT NULL, 
  `slastName` varchar(255) NOT NULL,
  `scrn` varchar(255) NOT NULL,
  `spassword` varchar(50) NOT NULL,
  `srollNo` varchar(10) NOT NULL,
  `sdateCreated` varchar(50) NOT NULL
);*/ 
 ?>
 <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="favicon.jpg" rel="icon" type="image/jpg" />
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/welcome.css" rel="stylesheet">
  </head>
  <body>	
    <?php require 'partials/_nav.php'?>
     <?php 
    if ($showAlert) {
     	echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success..!</strong> Student Data Added... 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
     if ($showError) {
     	echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error..!</strong>'.$showError.'
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
	?>
    <h1>Add Student</h1>
    <form method="post">
    	<label>Roll NO:</label>
    	<input type="number" name="srollno" required="">
  		<div class="row">
    		<div class="col">
    			<label>Enter First Name:</label>
      			<input type="text" name="sfirstname" class="form-control" placeholder="First name" required="">
    		</div>
    		<div class="col">
    			<label>Enter Middle Name:</label>
      			<input type="text" name="smiddlename" class="form-control" placeholder="Middle name" required="">
    		</div>
    		<div class="col">
    			<label>Enter Last Name:</label>
      			<input type="text" name="slastname"class="form-control" placeholder="Last name" required="">
    		</div>
  		</div><br>
  		<div class="form-check">
    		<label>Gender: </label>
    		<input type="radio" name="sgender" value="Male" required="">Male
			<input type="radio" name="sgender" value="Female">Female
			<input type="radio" name="sgender" value="Other">Other
		</div>	
		<br>
    	<label>Enter CRN:</label>
    	<input type="text" name="scrn" maxlength="6" required="">
    	
    	<label>Student Class:</label>
		<select name="sclass" required="">
			<option value="FYBSc(Computer Science)">FYBSc(Computer Science)</option>
			<option value="SYBSc(Computer Science)">SYBSc(Computer Science)</option>
			<option value="TYBSc(Computer Science)" selected>TYBSc(Computer Science)</option>
			<option value="MSC-1(Computer Science)">MSC-1(Computer Science)</option>
			<option value="MSC-2(Computer Science)">MSC-2(Computer Science)</option>
		</select><br><br>

		
		<button type="submit" class="btn btn-primary">Submit</button>
  		<button type="reset" class="btn btn-primary">Reset</button>
  		</fieldset>
	</form>
</body>
</html>
