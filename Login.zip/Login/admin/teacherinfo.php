<?php 
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
{
  header("location: login.php");
  exit;
}
else 
{
  include 'partials/_dbconnect.php';

} 
 ?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="favicon.jpg" rel="icon" type="image/jpg" />
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/welcome.css" rel="stylesheet">
    <title>Welcome <?php $_SESSION['username']; ?></title>
  </head>
  <body>
    
    <?php require 'partials/_nav.php'?>
    
    <div class="container my-3" >
      <div class="alert alert-success" role="alert">
        <h4 class="alert-heading">WelCome - <?php echo $_SESSION['username'] ?></h4>
      </div>
      <button type="submit" class="btn btn-primary" onclick="location.href='welcome.php';">Back</button>
    <button type="submit" class="btn btn-primary" onclick="location.href='addteacher.php';">Add Teacher</button>
    </div>
    <table class="table">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Gender</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
  <?php 
       $sql = "SELECT *  FROM `teacher`"; 
        $result = mysqli_query($conn, $sql);
        if ($result) 
        {
          while($row = mysqli_fetch_assoc($result))
          {
            $tId = $row["tid"];
            $tfirstName = $row["tfirstName"];
            $tmiddleName = $row["tmiddleName"];
            $tlastName  = $row["tlastName"];
            $tgender = $row["tgender"];
            
            echo '
            <tr>
              <th scope="row">'.$tId.'</th>
              <td>'.$tlastName.' '.$tfirstName.' '.$tmiddleName.'</td>
              <td>'.$tgender.'</td>
            </tr>';
          }  
        }
  ?>
  </tbody>
</table>
  </body>
</html>