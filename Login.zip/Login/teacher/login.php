<?php
$login = false;
$showError = false;
if($_SERVER['REQUEST_METHOD'] == "POST")
{
  include 'partials/_dbconnect.php';
  $username = $_POST["username"];
  $password = $_POST["password"];

  //$sql = "Select * from admin where ausername='$username' AND apassword='$password'";
  $sql = "Select * from teacher where tusername ='$username'";
  $result = mysqli_query($conn, $sql);
  $num = mysqli_num_rows($result);
  if($num == 1)
  {
      while($row = mysqli_fetch_assoc($result)) 
      {
        if(password_verify($password, $row['tpassword'])) 
        {
          $login = true;
          session_start();
          $_SESSION['loggedin'] = true;
          $_SESSION['username'] = $username;
          header("location: welcome.php");
        }
      }      
  }
  else
  {
      $showError = "Invalid Credentials";
  }
}

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="favicon.jpg" rel="icon" type="image/jpg" />
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/asignup.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->

    <title>Login</title>
  </head>
  <body>
    
    <?php require 'partials\_nav.php'?>
 <?php 
    if ($login) {
      echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success..!</strong> Your are logged in..
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
     if ($showError) {
      echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error..!</strong>'.$showError.'
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
?>
    <center>
    <div class="login-box">
    <h2>Teacher Login</h2>
    <form action="/Login/teacher/login.php" method="post">
      <div class="user-box">
        <input type="text"  maxlength="11" class="form-control" id="username" name="username" required="">
        <label for="username">Username</label>       
      </div>
      <div class="user-box">
        <input type="password" maxlength="255" class="form-control" id="password" name="password" required="">
        <label for="password">Password</label>
      </div>
      <button type="submit" class="btn btn-primary">Login</button><br><br>
      <p class="mb-0">Don't Have Account <a href="/Login/teacher/signup.php">Create Here..</a></p>
    </form>
  </div>
  </center>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>