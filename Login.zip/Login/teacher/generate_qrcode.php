<?php 
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true)
{
    header("location: login.php");
    exit;

}
else
{
            include 'partials/_dbconnect.php';
        $sql = "SELECT *  FROM `subjects`"; 
        $result = mysqli_query($conn, $sql);
        if ($result) 
        {
          while($row = mysqli_fetch_assoc($result))
          {
            $subjectID = $row["subject_id"];

           }
           
        }

        echo $subjectID;
    require_once('phpqrcode/qrlib.php');
    // Generate QR code function
function generateQRCode($data, $filename) {
    // QR code options
    $errorCorrectionLevel = 'L'; // L: Low, M: Medium, Q: Quality, H: High
    $matrixPointSize = 4; // 1 to 10 (default is 4)

    // Generate QR code
    QRcode::png($data, $filename, $errorCorrectionLevel, $matrixPointSize);
}

// Example usage
//$subjectID = '12345'; // Replace with the student's ID or any relevant data
$filename = 'qr_codes/'.$subjectID.'.png'; // Set the filename and path where the QR code will be saved

// Generate QR code
generateQRCode($subjectID, $filename);

// Display the QR code image
echo '<img src="'.$filename.'" alt="QR Code">';
}
 ?>