<?php
$login = false;
$showError = false;
	include 'partials/_dbconnect.php';
if($_SERVER['REQUEST_METHOD'] == "POST")
{
	$username = $_POST["username"];
	$password = $_POST["password"];

  //$sql = "Select * from admin where ausername='$username' AND apassword='$password'";
  $sql = "Select * from admin where ausername='$username'";
  $result = mysqli_query($conn, $sql);
	$num = mysqli_num_rows($result);
	if($num == 1)
  {
		  while($row = mysqli_fetch_assoc($result)) 
      {
        if(password_verify($password, $row['apassword'])) 
        {
          $login = true;
          session_start();
          $_SESSION['loggedin'] = true;
          $_SESSION['username'] = $username;
          header("location: welcome.php");
        }
      }      
	}
  else
  {
			$showError = "Invalid Credentials";
	}
}

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="favicon.jpg" rel="icon" type="image/jpg" />
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/asignup.css" rel="stylesheet">

    <title>Login</title>
  </head>
  <body>
  	
    <?php require 'partials\_nav.php'?>
 <?php 
    if ($login) {
     	echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success..!</strong> Your are logged in..
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
     if ($showError) {
     	echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error..!</strong>'.$showError.'
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
?>
    <center>
    <div class="login-box">
    <h2>Admin Login</h2>
    <form method="post">
      <div class="user-box">
        <input type="text"  maxlength="11" class="form-control" id="username" name="username" required="">
        <label for="username">Username</label>       
      </div>
      <div class="user-box">
        <input type="password" maxlength="255" class="form-control" id="password" name="password" required="">
        <label for="password">Password</label>
      </div>
      <button type="submit" class="btn btn-primary">Login</button><br><br>
      <p class="mb-0">Don't Have Account <a href="signup.php">Create Here..</a></p>
    </form>
  </div>
  </center>
  </body>
</html>