<?php
$showAlert = false;
$showError = false;
include 'partials/_dbconnect.php';
if($_SERVER['REQUEST_METHOD'] == "POST")
{
	$username = $_POST["username"];
	$password = $_POST["password"];
	$cpassword = $_POST["cpassword"];

	//Check whether this username Exixst
	$existSql = "SELECT *  FROM `admin` WHERE ausername='$username'"; 
	$result = mysqli_query($conn, $existSql);
	$numExistRows = mysqli_num_rows($result);
	if($numExistRows > 0)
  {
		$showError = "Username Already Exists..!";
	}
	else
  {

		if (($password == $cpassword))
    {

		$hash = password_hash($password, PASSWORD_DEFAULT);//password convert in hash//
		$sql = "INSERT INTO `admin` (`ausername`, `apassword`, `adt`) VALUES ('$username', '$hash', current_timestamp())";
		$result = mysqli_query($conn, $sql);
		if($result)
    {
			$showAlert = true;
		}
	}
	else
  {
		$showError = "Password Do Not Match";
	}
}

}
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/asignup.css" rel="stylesheet">
    <link href="favicon.jpg" rel="icon" type="image/jpg" />

    <title>Sign Up</title>
  </head>
  <body>
  	
    <?php require 'partials/_nav.php'?>
 <?php 
    if ($showAlert) {
     	echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>Success..!</strong> Your Account is now created and You can login. 
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
     if ($showError) {
     	echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error..!</strong>'.$showError.'
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';
     } 
?>
    <div class="login-box">
    	<h1>Sign Up for Admin</h1>
    	<center>
    	<form method="post">
        <div class="user-box">
          <input type="text"  maxlength="11" class="form-control" id="username" name="username" required="">
          <label for="username">Username</label>       
        </div>
        <div class="user-box">
          <input type="password" maxlength="255" class="form-control" id="password" name="password" required="">
          <label for="password">Password</label>
        </div>
  			<div class="user-box" >
          <input type="password" maxlength="255" class="form-control" id="cpassword" name="cpassword" required="">
          <label for="cpassword">Confirm Password</label>
  			</div>
  			<button type="submit" class="btn btn-primary">Submit</button>
  			<button type="reset" class="btn btn-primary">Reset</button>
  			<br><br>
  			<div>
  			 <p class="mb-0">Already Have Account <a href="login.php">Login Here..</a></p>
			</div>
		</form>	
		</center>
    </div>
  </body>
</html>